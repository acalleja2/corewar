#include "corewar.h"

void		ins_lld(t_proc *process, t_data *data)
{
}
