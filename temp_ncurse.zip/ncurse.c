#include "corewar.h"

int			ncurses_main_loop(WINDOW *map, t_data *data)
{
	int		ch;

	print_map(map, HEIGHT, WIDTH);
	ch = wgetch(map);
	if (ch == 'q')
		return (1);
	wrefresh(map);
	refresh_sleep(0);
	return (0);
}

void		end_ncurses(WINDOW *map, t_data *data)
{
	if (data->args->ncurses == -1)
		return ;
	refresh_sleep(1);
	destroy_win(map);
	endwin();
}

WINDOW		*init_ncurse(t_data *data)
{
	int		rows;
	int		cols;
	WINDOW	*map;

	if (data->args->ncurses == -1)
		return (NULL);
	init_main_window();
	getmaxyx(stdscr, cols, rows);
	print_usage(rows, cols);
	refresh_sleep(1);
	map = create_newwin(HEIGHT + 2, WIDTH + 2, STARTX, STARTY); 
	nodelay(map, TRUE);
	return (map);
}
