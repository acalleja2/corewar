#include "corewar.h"

void		ins_ld(t_proc *process, t_data *data)
{
}
