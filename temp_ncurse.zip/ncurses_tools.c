#include "corewar.h"

WINDOW		*create_newwin(int height, int width, int starty, int startx)
{
	WINDOW	*local_win;
	local_win = newwin(height, width, starty, startx);
	box(local_win, '|', '-');
	wmove(local_win, 1, 1);
	wrefresh(local_win);
	return (local_win);
}

void	clear_win(WINDOW *win, int height, int width)
{
	int		i;
	int		j;

	j = 1;
	i = 1;
	while (j <= height)
	{
		while (i <= width)
		{
			mvwprintw(win, j, i, " ");
			i++;
		}
		i = 1;
		j++;
	}
	wrefresh(win);
}

void	destroy_win(WINDOW *local_win)
{
	int		rows;
	int		cols;

	getmaxyx(local_win, cols, rows);
	clear_win(local_win, cols - 2 , rows - 2);
	mvwprintw(local_win, cols / 2, rows / 2, "BYE");
	wrefresh(local_win);
	sleep(1);
	wborder(local_win ,' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '); 
	clear_win(local_win, cols - 2 , rows - 2);
	wrefresh(local_win);
	sleep(1);
	delwin(local_win);
}

void	print_map(WINDOW *win, int height, int width)
{
	int		i;
	int		j;
	int		cp;

	j = 1;
	i = 1;
	cp = 0;
	while (j <= height)
	{
		while (i <= width)
		{
			mvwprintw(win, j, i, "0");
			i++;
			cp++;
		}
		i = 1;
		j++;
	}
	wrefresh(win);
	//wprintw(win, "charaters printed: %d\n", cp);
}
