#include "corewar.h"

void	refresh_sleep(int sleep_time)
{
	refresh();
	if (sleep_time > 0)
		sleep(sleep_time);
}

void	print_usage(int rows, int cols)
{
	mvprintw(0, rows / 2, "COREWAR NCURSE OUTPUT MODE\n");
	printw("q => quit");
	refresh();
}


void	init_main_window()
{
	initscr();
	raw();
	keypad(stdscr, TRUE);
	noecho();
}

void	ncurses_winner(char	*speak, t_data *data, WINDOW *map)
{
	int		cols;
	int		rows;

	getmaxyx(map, cols, rows);
	clear_win(map, cols, cols);
}
