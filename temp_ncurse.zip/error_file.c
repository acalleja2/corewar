#include "corewar.h"

void	ft_error_file(char *champ)
{
	ft_printf("File %s does not exists!\n", champ);
	exit(0);
}
