#include "corewar.h"

void		ins_lfork(t_proc *process, t_data *data)
{
}
