#include "corewar.h"

void		ins_xor(t_proc *process, t_data *data)
{
}
