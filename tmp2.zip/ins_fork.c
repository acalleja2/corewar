#include "corewar.h"

void		ins_fork(t_proc *process, t_data *data)
{
}
