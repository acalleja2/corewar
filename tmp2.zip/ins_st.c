#include "corewar.h"

void		ins_st(t_proc *process, t_data *data)
{
}
