#include "corewar.h"

void		ins_aff(t_proc *process, t_data *data)
{
}
