#include "corewar.h"

void		ins_and(t_proc *process, t_data *data)
{
}
