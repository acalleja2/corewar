#include "corewar.h"

void		ins_lldi(t_proc *process, t_data *data)
{
}
