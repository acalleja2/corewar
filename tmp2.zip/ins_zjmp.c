#include "corewar.h"

void		ins_zjmp(t_proc *process, t_data *data)
{
}
