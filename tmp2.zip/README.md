## A faire
- [ ] Discuter nom champion doublon possible? Il se bat contre lui-meme
- [ ] Tests parser en profondeur
- [ ] Si tests ok, mettre au propre + finir doc (preciser entrees/sorties)
- [ ] La VM :/

## Fait
- [x] Option v lors du parsing, et verif des bits sets avec masks.
- [x] Nombre variable de champions (voir op.h)
- [x] verifier numero process valides => permetra de generaliser l'initialisation des process.
- [x] Generer une liste chainee avec les champions
- [x] Recuperer le nom, la description, le poids et le code de chaque champion
- [x] Initialisation des process dans boucle.
- [x] Chargement des programmes en memoire
