#include "corewar.h"

void		ins_ldi(t_proc *process, t_data *data)
{
}
